## Kubernetes Model

### Landing Page and Network Policies

![alt text](https://github.com/paulovigne/goapp/blob/master/goapp-appref-extra.png?raw=true)
